class Getdata {

    constructor() {
        document.addEventListener('mousemove', stationNameOne();

            this.onMouseMove();

        }


    }