import TrainData1 from './modules/TrainData1.js'
import TrainMoving from './modules/TrainMoving.js'

let trainData1 = new TrainData1;
trainData1.getTrainTime();

new TrainMoving;